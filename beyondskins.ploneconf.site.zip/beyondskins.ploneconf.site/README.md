beyondskins.ploneconf.site
==========================

Diazo Theme for Plone Conference 2013

Changelog
---------

0.2
^^^
* Implementação do layout definitivo. [agnogueira]

0.1
^^^
* Tema provisório para o portal. [agnogueira]

Credits
-------

Development of this theme was sponsored by `Simples Consultoria
<http://www.simplesconsultoria.com.br/>`_.
